import { Component, OnInit, TemplateRef  } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';
import { BsModalRef,ModalModule ,BsModalService } from 'ngx-bootstrap/modal';
import { DatePipe } from '@angular/common';
@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  bookData: any;
  modalRef: BsModalRef;
  bookdetailForm: FormGroup;
  editDeleteIndex = -1;
  sortFlag = false;
  tempBookData: any;
  constructor(private adminService: AdminService, private router: Router, private modalService: BsModalService,
  private date: DatePipe) {
  }

  ngOnInit() {
    this.bookdetailForm = new FormGroup({
      id: new FormControl(),
      title: new FormControl(),
      description: new FormControl(),
      publishdate: new FormControl(),
      excerpt: new FormControl(),
      count: new FormControl()
    });
    this.adminService.getBooks().subscribe(data => {
      if(data) {
        this.bookData = data;
        this.tempBookData = JSON.parse(JSON.stringify(this.bookData));
      } else { console.log('No Books Available'); }
    });
  }
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
  bookdetail(formValue) {
    if (this.editDeleteIndex < 0) {
    formValue.id = this.bookData.length + 2;
    }
    const data = {
    "ID": formValue.id,
    "Title": formValue.title,
    "Description": formValue.description,
    "PageCount": formValue.count,
    "Excerpt": formValue.excerpt,
    "PublishDate": formValue.publishdate
    }
    console.log(this.bookdetailForm.value);
    if (this.editDeleteIndex >= 0) {
      this.bookData[this.editDeleteIndex] = data;
    } else {
    this.bookData.push(data);
    this.tempBookData = JSON.parse(JSON.stringify(this.bookData));
    }
    console.log(this.bookData);
    this.editDeleteIndex = -1;
    this.modalRef.hide()
  }
  edit(index, template: TemplateRef<any>) {
    this.editDeleteIndex = index;
    this.openModal(template)
    this.bookdetailForm.patchValue({
      id: (index > -1) ? this.bookData[index].ID : '',
      title: (index > -1) ? this.bookData[index].Title : '',
      description: (index > -1) ? this.bookData[index].Description : '',
      publishdate: (index > -1) ? (this.date.transform(this.bookData[index].PublishDate, 'yyyy-MM-dd')) : '',
      count: (index > -1) ? this.bookData[index].PageCount : '',
      excerpt: (index > -1) ? this.bookData[index].Excerpt : ''
    });
  }
  delete(index, template: TemplateRef<any>) {
    this.openModal(template);
    this.editDeleteIndex = index;
  }
  confirmDelete() {
    this.bookData[this.editDeleteIndex] = {};
    const updatedData = this.bookData.filter(a => a.Title);
    console.log(updatedData);
    this.bookData = updatedData;
    this.tempBookData = JSON.parse(JSON.stringify(this.bookData));
    this.editDeleteIndex = -1;
    this.modalRef.hide();
  }
  sort() {
    let temp: any;
    this.sortFlag = !this.sortFlag;
    for (let i = 0; i< this.bookData.length -1; i++) {
      for (let j = i+1; j< this.bookData.length; j++) {
        if(this.sortFlag === false) {
        if (new Date(this.bookData[i].PublishDate) > new Date(this.bookData[j].PublishDate)) {
          temp = this.bookData[i];
          this.bookData[i] = this.bookData[j];
          this.bookData[j] = temp;
        }
      } else {
          if (new Date(this.bookData[i].PublishDate) < new Date(this.bookData[j].PublishDate)) {
          temp = this.bookData[i];
          this.bookData[i] = this.bookData[j];
          this.bookData[j] = temp;
        }
      }
    }
  } 
  }
}
