import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { AdminService } from '../admin.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  error = false;
  loginForm: FormGroup;
  userData: any;
  loggedIn= false;
  constructor(private adminService: AdminService, private router: Router) { }

  ngOnInit() {
    this.loginForm = new FormGroup({
      username: new FormControl(),
      password: new FormControl()
    });
  }

  logIn(formValue) {
    console.log(formValue);
    this.adminService.getUser().subscribe(data => {
      this.userData = data;
      console.log(this.userData);
      for(let a of this.userData) {
        if ((a.UserName === formValue.username) && (a.Password === formValue.password)) {
          this.error = false;
          this.loggedIn = true;
          this.router.navigate(['booklist']);
        } 
      }
      if(!this.loggedIn) {
        this.error = true;
      }
    });
    console.log(this.loginForm.value);
  }
}
