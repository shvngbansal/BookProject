import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';
import { AdminService } from './admin.service';
import { AppComponent } from './app.component';
import { BooklistComponent } from './booklist/booklist.component';
import { LoginComponent } from './login/login.component';
import { BsModalRef,ModalModule ,BsModalService  } from 'ngx-bootstrap/modal';
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [
    AppComponent,
    BooklistComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    ModalModule.forRoot(),
    RouterModule.forRoot([
      { 
        path: '',  redirectTo: '/login', pathMatch: 'full',
      },
      { 
        path: 'login', component: LoginComponent,
      },
      { 
        path: 'booklist', component: BooklistComponent
      },
      { path: '**', redirectTo: '' }
    ])
  ],
  providers: [AdminService, DatePipe],
  bootstrap: [AppComponent],
})
export class AppModule { }
