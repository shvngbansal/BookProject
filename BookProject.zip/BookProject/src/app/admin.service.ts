import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import 'rxjs/add/operator/map';
@Injectable()
export class AdminService {

  constructor(private http: HttpClient) { }

  getUser (): Observable<any[]> {
    // return this.http.get('../assets/admin.json').map((response: Response) => {
    //   response;
    // });
    return this.http.get('../assets/admin.json');
  }

  getBooks (): Observable<any[]> {
    return this.http.get('../assets/books.json');
  }
}
